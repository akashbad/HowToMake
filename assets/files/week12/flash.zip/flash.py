#!/usr/bin/env python
#
# interface.py
#
# interface.py serial_port port_speed
#

import sys,time,serial
from Tkinter import *
from select import *

WINDOW = 600

def key(event):
   #
   # key press event handles
   #
   key = event.char
   #print 'send',ord(key)
   if (ord(key) == 13):
      key = chr(10)
   write(key)

def quit():
   #
   # clean up and quit
   #
   sys.exit()

def click(event):
  #
  # click event handler
  #
  write(str(event.widget.find_closest(event.x, event.y)[0] - 1))

def write(message):
  ser.write(message)
  canvas.itemconfig('button0',fill='red')
  canvas.itemconfig('button1',fill='red')
  canvas.itemconfig('button2',fill='red')
  canvas.after(100,flash,'button0',canvas)
  canvas.after(100,flash,'button1',canvas)
  canvas.after(100,flash,'button2',canvas)
  canvas.after(200,flash,'button' + message, canvas)
  canvas.after(300,flash,'button' + message, canvas)

def flash(rect,canvas):
  current_color = canvas.itemcget(rect, "fill")
  new_color = "blue" if current_color == "red" else "red"
  canvas.itemconfigure(rect, fill=new_color)

#
#  check command line arguments
#
if (len(sys.argv) != 3):
   print "command line: term.py serial_port speed"
   sys.exit()
port = sys.argv[1]
speed = int(sys.argv[2])
#
# open serial port
#
ser = serial.Serial(port,speed)
ser.setDTR()
#
# flush buffers
#
ser.flushInput()
ser.flushOutput()
#
# set up UI
#
root = Tk()
root.bind('<Key>',key)



root.title('flash.py')
#
widget_quit = Button(root, text="quit",command=quit)
widget_quit.pack()
#
address_frame = Frame(root)
Label(address_frame,text="port: "+port).pack(side='left')
Label(address_frame,text="  speed: "+str(speed)).pack(side='left')
address_frame.pack()
#
canvas = Canvas(root, width=WINDOW, height = .75*WINDOW, background = 'white');
canvas.create_rectangle(.1*WINDOW,.25*WINDOW,.3*WINDOW,.5*WINDOW, tags='button0', fill='#0000ff')
canvas.create_rectangle(.4*WINDOW,.25*WINDOW,.6*WINDOW,.5*WINDOW, tags='button1', fill='#0000ff')
canvas.create_rectangle(.7*WINDOW,.25*WINDOW,.9*WINDOW,.5*WINDOW, tags='button2', fill='#0000ff')
canvas.tag_bind('button0','<ButtonPress-1>', click)
canvas.tag_bind('button1','<ButtonPress-1>', click)
canvas.tag_bind('button2','<ButtonPress-1>', click)
canvas.pack();

#
#
root.mainloop()
