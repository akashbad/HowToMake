// FabBlaster
// Akash Badshah
//
// 9600 baud FTDI interface
//

#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include <stdio.h>
#include <avr/pgmspace.h>
#include <string.h>

#define output(directions,pin) (directions |= pin) // set port direction for output
#define set(port,pin) (port |= pin) // set port pin
#define clear(port,pin) (port &= (~pin)) // clear port pin
#define pin_test(pins,pin) (pins & pin) // test for port pin
#define bit_test(byte,bit) (byte & (1 << bit)) // test for bit set
#define bit_delay_time 100 // bit delay for 9600 with overhead
#define bit_delay() _delay_us(bit_delay_time) // RS232 bit delay
#define half_bit_delay() _delay_us(bit_delay_time/2) // RS232 half bit delay
#define charge_delay() _delay_us(1) // charge delay 1
#define settle_delay() _delay_us(100) // settle delay
#define char_delay() _delay_ms(10) // char delay

//Communications Pins
#define serial_port PORTB
#define serial_direction DDRB
#define serial_pin_rx (1 << PB2)
#define serial_pin_tx (1 << PB1)

#define mute_pin (1 << PB0)

//All other pins are on port a
//Command Pins
#define pwren_pin (1 << PA0)
#define cmd_pin (1 << PA1)
#define step_pin (1 << PA7)

#define vol_up_pin (0 << MUX2) | (1 << MUX1) | (0 << MUX0) // PA2
#define next_pin (0 << MUX2) | (1 << MUX1) | (1 << MUX0) // PA3
#define play_pin (1 << MUX2) | (0 << MUX1) | (0 << MUX0) // PA4
#define prev_pin (1 << MUX2) | (0 << MUX1) | (1 << MUX0) // PA5
#define vol_dn_pin (1 << MUX2) | (1 << MUX1) | (0 << MUX0) // PA6

#define ref (0 << REFS1) | (0 << REFS0) // reference voltage

#define threshold 700

void get_char(volatile unsigned char *pins, unsigned char pin, char *rxbyte) {
   //
   // read character into rxbyte on pins pin
   //    assumes line driver (inverts bits)
   //
   *rxbyte = 0;
   while (pin_test(*pins,pin))
      //
      // wait for start bit
      //
      ;
   //
   // delay to middle of first data bit
   //
   half_bit_delay();
   bit_delay();
   //
   // unrolled loop to read data bits
   //
   if pin_test(*pins,pin)
      *rxbyte |= (1 << 0);
   else
      *rxbyte |= (0 << 0);
   bit_delay();
   if pin_test(*pins,pin)
      *rxbyte |= (1 << 1);
   else
      *rxbyte |= (0 << 1);
   bit_delay();
   if pin_test(*pins,pin)
      *rxbyte |= (1 << 2);
   else
      *rxbyte |= (0 << 2);
   bit_delay();
   if pin_test(*pins,pin)
      *rxbyte |= (1 << 3);
   else
      *rxbyte |= (0 << 3);
   bit_delay();
   if pin_test(*pins,pin)
      *rxbyte |= (1 << 4);
   else
      *rxbyte |= (0 << 4);
   bit_delay();
   if pin_test(*pins,pin)
      *rxbyte |= (1 << 5);
   else
      *rxbyte |= (0 << 5);
   bit_delay();
   if pin_test(*pins,pin)
      *rxbyte |= (1 << 6);
   else
      *rxbyte |= (0 << 6);
   bit_delay();
   if pin_test(*pins,pin)
      *rxbyte |= (1 << 7);
   else
      *rxbyte |= (0 << 7);
   //
   // wait for stop bit
   //
   bit_delay();
   half_bit_delay();
   }


//Neil's Code to transmit chars
void put_char(volatile unsigned char *port, unsigned char pin, char txchar) {
	//
	// send character in txchar on port pin
	//	 assumes line driver (inverts bits)
	//
	// start bit
	//
	clear(*port,pin);
	bit_delay();
	//
	// unrolled loop to write data bits
	//
	if bit_test(txchar,0)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,1)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,2)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,3)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,4)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,5)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,6)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,7)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	//
	// stop bit
	//
	set(*port,pin);
	bit_delay();
	//
	// char delay
	//
	bit_delay();
}

void reset()
{
  put_char(&serial_port, serial_pin_tx, 'R');
  put_char(&serial_port, serial_pin_tx, ',');
  put_char(&serial_port, serial_pin_tx, '1');
  put_char(&serial_port, serial_pin_tx, 13);
}

void vol_dn()
{
  put_char(&serial_port, serial_pin_tx, 'A');
  put_char(&serial_port, serial_pin_tx, 'V');
  put_char(&serial_port, serial_pin_tx, '-');
  put_char(&serial_port, serial_pin_tx, 13);
}

void prev()
{
  put_char(&serial_port, serial_pin_tx, 'A');
  put_char(&serial_port, serial_pin_tx, 'T');
  put_char(&serial_port, serial_pin_tx, '-');
  put_char(&serial_port, serial_pin_tx, 13);
}

void play()
{
  put_char(&serial_port, serial_pin_tx, 'A');
  put_char(&serial_port, serial_pin_tx, 'P');
  put_char(&serial_port, serial_pin_tx, 13);
}

void next()
{
  put_char(&serial_port, serial_pin_tx, 'A');
  put_char(&serial_port, serial_pin_tx, 'T');
  put_char(&serial_port, serial_pin_tx, '+');
  put_char(&serial_port, serial_pin_tx, 13);
}

void vol_up()
{
  put_char(&serial_port, serial_pin_tx, 'A');
  put_char(&serial_port, serial_pin_tx, 'V');
  put_char(&serial_port, serial_pin_tx, '+');
  put_char(&serial_port, serial_pin_tx, 13);
}

//Check an ADCPin identified by bitmask
int check_pin(unsigned char pin) {
	unsigned char up_lo,up_hi,down_lo,down_hi;
	int up_value, down_value, value;
	
	//
	// set the A/D pin
	//
	ADMUX = ref | pin;
	
	//
	// settle, charge, and wait 1
	//
	settle_delay();
	set(PORTA, step_pin);
	charge_delay();
	//
	// initiate conversion
	//
	ADCSRA |= (1 << ADSC);
	//
	// wait for completion
	//
	while (ADCSRA & (1 << ADSC))
		;
	//
	// save result
	//
	up_lo = ADCL;
	up_hi = ADCH;
	//
	// settle, discharge, and wait 1
	//
	settle_delay();
	clear(PORTA, step_pin);
	charge_delay();
	//
	// initiate conversion
	//
	ADCSRA |= (1 << ADSC);
	//
	// wait for completion
	//
	while (ADCSRA & (1 << ADSC))
		;
	//
	// save result
	//
	down_lo = ADCL;
	down_hi = ADCH;
	//
	// process result
	//
	up_value = 256 * up_hi + up_lo;
	down_value = 256 * down_hi + down_lo;
	value = (up_value + (1023 - down_value)) / 2;	
	return value;
}

int main(void) {
	//
	// main
	//
	//
	// set clock divider to /1
	//
	CLKPR = (1 << CLKPCE);
	CLKPR = (0 << CLKPS3) | (0 << CLKPS2) | (0 << CLKPS1) | (0 << CLKPS0);

  //
	// initialize output pins
	//
  set(serial_port, serial_pin_tx);
  output(serial_direction, serial_pin_tx); 
  
  //Set mute
  output(serial_direction, mute_pin);
  clear(serial_port, mute_pin);
  
  //Power on the module
  output(DDRA, pwren_pin);
  output(DDRA, cmd_pin);
  output(DDRA, step_pin);
  
  set(PORTA, pwren_pin);
  clear(PORTA, step_pin);
	//
	// init A/D
	//
	ADMUX = ref; // Vcc ref
	ADCSRA = (1 << ADEN) // enable
		| (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0); // prescaler /128
	ADCSRB = (0 << ADLAR); // right adjust
  
  //Wait for power on to enter command mode
  _delay_ms(1000);
  clear(PORTA, cmd_pin);

  //Reset the module after waiting to enter command mode
  _delay_ms(1000);
  //Delay for startup
  _delay_ms(10000);
  set(serial_port, mute_pin);
  play();
  int val = 0;
  while(1)
  {
    if(check_pin(vol_dn_pin) < threshold)
    {
      vol_dn();
      _delay_ms(1000);
    }
    if(check_pin(prev_pin) < threshold)
    {
      prev();
      _delay_ms(1000);
    }
    if(check_pin(play_pin) < threshold)
    {
      play();
      _delay_ms(1000);
    }
    if(check_pin(next_pin) < threshold)
    {
      next();
      _delay_ms(1000);
    }
    if(check_pin(vol_up_pin) < threshold)
    {
      vol_up();
      _delay_ms(1000);
    }
  }
}
