make -f beatpad.c.make
make -f beatpad.c.make program-usbtiny-fuses
make -f beatpad.c.make program-usbtiny
