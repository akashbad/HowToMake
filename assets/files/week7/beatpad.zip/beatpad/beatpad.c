//
//
// BeatPad
//
// Flashing light dual button beatpad
//
// set lfuse to 0x7E for 20 MHz xtal
//
// Akash Badshah
// 10/25/2013
//

#include <avr/io.h>
#include <util/delay.h>
#include <avr/pgmspace.h>

#define set(byte,bit) (byte |= bit) // set a bit
#define clear(byte,bit) (byte &= (~bit)) // clear a bit
#define test(byte,bit) (byte & bit) // test a bit
#define toggle(byte, bit) (byte ^= bit) // toggle a bit

//RightLED at PA3, LeftLED at PA7
//RightButton at PA2, LeftButton at PB2 
#define RightLED ( 1 << PA7)
#define RightButton ( 1 << PA2)
#define LeftLED ( 1 << PA3)
#define LeftButton ( 1 << PB2)

#define RecordingState ( 1 << 0)
#define WaitingState (1 << 1)
#define RightButtonState (1 << 2)
#define LeftButtonState (1 << 3)

#define MaxBuffer 50

void delay_ms(uint16_t count){
  while(count--){
    _delay_ms(1);
  }
}

int main(void) {
  // set clock divider to /1
  CLKPR = (1 << CLKPCE);
  CLKPR = (0 << CLKPS3) | (0 << CLKPS2) | (0 << CLKPS1) | (0 << CLKPS0);
  
  //Set up variables for program 
  static unsigned int RightBufferSize = MaxBuffer;
  static unsigned int LeftBufferSize = MaxBuffer;
  static unsigned int RightBuffer[MaxBuffer] = {0};
  static unsigned int LeftBuffer[MaxBuffer] = {0};
  static unsigned int RightCounter = 0;
  static unsigned int LeftCounter= 0;
  static unsigned int LeftIndex = 0;
  static unsigned int RightIndex = 0;
  static unsigned int WaitCounter = 0;

  //Set up state machine
  static char state = 0;
  clear(state, RecordingState);
  clear(state, WaitingState);

  //Test fill the buffer with some pattern
  int i;
  for(i=0; i<MaxBuffer; i++){
    RightBuffer[i] = 10*(i+1);
    LeftBuffer[i] = 10*(MaxBuffer-i);
  } 
  

  // initialize input and output pins 
  //LED's to output
  set(DDRA, RightLED);
  set(DDRA, LeftLED);
  //Buttons to Input
  clear(DDRA, RightButton);
  clear(DDRB, LeftButton);
  //Pull-up resistors on the buttons
  set(PORTA, RightButton);
  set(PORTB, LeftButton); 
 
  //Start the lights on
  set(PORTA, RightLED);
  set(PORTA, LeftLED);
 
  // main loop 
  while (1) {
    //Pick a mode
    if(test(state, RecordingState)){
      //Record Mode
      //Nominal Incrementation
      RightCounter++;
      LeftCounter++;
      //Check for Pin Change
      if(test(state,RightButtonState) != test(PINA, RightButton)){
        RightBuffer[RightIndex] = RightCounter;
        RightCounter = 0;
        RightIndex++;
        toggle(state, RightButtonState);
        set(PINA, RightLED);
      }
      if(test(state,LeftButtonState) != test(PINB, LeftButton)){
        /*LeftBuffer[LeftIndex] = LeftCounter;
        LeftCounter = 0;
        LeftIndex++;
        toggle(state, LeftButtonState);
        set(PINA, LeftLED);*/
      }
      //We exceeded the recording limit, switch back to play
      if(RightIndex == MaxBuffer || LeftIndex == MaxBuffer) {
        //Flicker the lights to tell the user
        int i = 6;
        set(PORTA, RightLED);
        set(PORTA, LeftLED);
        while(i--){
          set(PINA, RightLED);
          set(PINA, LeftLED);
          _delay_ms(100);
        }
        //Reset wait state and change
        toggle(state, RecordingState); 
        RightBufferSize = RightIndex;
        LeftBufferSize = LeftIndex;
        RightIndex = 0;
        LeftIndex = 0;
        RightCounter = RightBuffer[RightIndex];
        LeftCounter = LeftBuffer[LeftIndex];
      }
      
    } else {
      //Play Mode
      if(RightCounter == 0){
        set(PINA, RightLED);
        RightIndex = (RightIndex+1) % RightBufferSize;
        RightCounter = RightBuffer[RightIndex];
      }
      RightCounter--; 
      if(LeftCounter == 0){
        set(PINA, LeftLED);
        LeftIndex = (LeftIndex+1) % LeftBufferSize;
        LeftCounter = LeftBuffer[LeftIndex];
      }
      LeftCounter--;
    }
    //Testing for Wait State
    if(!test(PINA, RightButton) && !test(PINB, LeftButton)){
      //Increment and continue
      set(state, WaitingState);
      WaitCounter++;
      //Done waiting, lets change state
      if(WaitCounter > 1000){
        //Flicker the lights to tell the user
        int i = 6;
        set(PORTA, RightLED);
        set(PORTA, LeftLED);
        while(i--){
          set(PINA, RightLED);
          set(PINA, LeftLED);
          _delay_ms(100);
        }
        //Reset wait state and change
        WaitCounter = 0;
        clear(state, WaitingState);
        toggle(state, RecordingState);
        //Allow the user time to move their fingers
        _delay_ms(500);  
        //Set up variables
        if(test(state, RecordingState)){
          RightCounter = 0;
          LeftCounter = 0;
        } else {
          RightBufferSize = RightIndex % 2 == 0 ? RightIndex : RightIndex - 1;
          LeftBufferSize = LeftIndex % 2 == 0 ? LeftIndex : LeftIndex - 1;
          RightCounter = RightBuffer[0];
          LeftCounter = LeftBuffer[0];
        }
        RightIndex = 0;
        LeftIndex = 0;
      }
    } else if(test(state, WaitingState)){
      //We didn't hit it, end wait cycle
      WaitCounter = 0;
      clear(state, WaitingState);
    }

    //Run on a 1ms overall cycle to prevent memory overflow 
    _delay_ms(1);
  }
}
